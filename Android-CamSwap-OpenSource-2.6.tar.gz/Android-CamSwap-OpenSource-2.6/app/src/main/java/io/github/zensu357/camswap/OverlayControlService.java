package io.github.zensu357.camswap;

import android.animation.ValueAnimator;
import android.app.Service;
import android.content.Context;
import android.content.Intent;
import android.content.res.ColorStateList;
import android.content.res.Resources;
import android.graphics.Color;
import android.graphics.PixelFormat;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.graphics.drawable.RippleDrawable;
import android.os.Build;
import android.os.IBinder;
import android.provider.Settings;
import android.util.TypedValue;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewConfiguration;
import android.view.WindowManager;
import android.view.animation.DecelerateInterpolator;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.TextView;

public class OverlayControlService extends Service {
    private static final int EDGE_MARGIN_DP = 12;
    private static final float SCALE_FACTOR = 0.8f;
    private static final int INNER_GAP_DP = 6;

    private WindowManager windowManager;
    private LinearLayout contentContainer;
    private FrameLayout rootView;
    private LinearLayout actionPanel;
    private TextView bubbleView;
    private WindowManager.LayoutParams layoutParams;
    private ValueAnimator snapAnimator;
    private boolean isExpanded;
    private boolean snappedToRight = true;

    @Override
    public void onCreate() {
        super.onCreate();
        if (!Settings.canDrawOverlays(this)) {
            stopSelf();
            return;
        }
        windowManager = (WindowManager) getSystemService(WINDOW_SERVICE);
        showOverlay();
    }

    @Override
    protected void attachBaseContext(Context newBase) {
        super.attachBaseContext(io.github.zensu357.camswap.utils.LocaleHelper.INSTANCE.onAttach(newBase));
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        if (!Settings.canDrawOverlays(this)) {
            stopSelf();
            return START_NOT_STICKY;
        }
        showOverlay();
        return START_STICKY;
    }

    @Override
    public void onDestroy() {
        super.onDestroy();
        removeOverlay();
    }

    @Override
    public IBinder onBind(Intent intent) {
        return null;
    }

    private void showOverlay() {
        if (windowManager == null || rootView != null) {
            return;
        }

        rootView = new FrameLayout(this);
        rootView.setClipChildren(false);
        rootView.setClipToPadding(false);
        int outerPadding = dpScaled(6);
        rootView.setPadding(outerPadding, outerPadding, outerPadding, outerPadding);

        contentContainer = new LinearLayout(this);
        contentContainer.setOrientation(LinearLayout.HORIZONTAL);
        contentContainer.setGravity(Gravity.CENTER_VERTICAL);
        contentContainer.setClipChildren(false);
        contentContainer.setClipToPadding(false);

        actionPanel = new LinearLayout(this);
        actionPanel.setOrientation(LinearLayout.HORIZONTAL);
        actionPanel.setGravity(Gravity.CENTER_VERTICAL);
        int panelPaddingH = dpScaled(8);
        int panelPaddingV = dpScaled(8);
        actionPanel.setPadding(panelPaddingH, panelPaddingV, panelPaddingH, panelPaddingV);
        actionPanel.setVisibility(View.GONE);
        actionPanel.setBackground(makePanelBackground());
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
            actionPanel.setElevation(dpScaled(6));
        }

        actionPanel.addView(makeActionButton(getString(R.string.notif_action_next), resolveMonetColor(0xFF6650A4),
                v -> ControlActionHelper.switchVideo(this, true)));
        actionPanel.addView(makeSpacer());
        actionPanel.addView(makeActionButton(getString(R.string.overlay_action_rotate), resolveMonetColor(0xFF7D5260),
                v -> ControlActionHelper.rotateVideo(this)));

        bubbleView = new TextView(this);
        bubbleView.setText("CS");
        bubbleView.setTextColor(resolveOnAccentColor());
        bubbleView.setTextSize(TypedValue.COMPLEX_UNIT_SP, 13f);
        bubbleView.setGravity(Gravity.CENTER);
        bubbleView.setTypeface(Typeface.create(Typeface.SANS_SERIF, Typeface.BOLD));
        bubbleView.setBackground(makeBubbleBackground());
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
            bubbleView.setElevation(dpScaled(6));
        }

        int bubbleSize = dpScaled(45);
        LinearLayout.LayoutParams bubbleParams = new LinearLayout.LayoutParams(bubbleSize, bubbleSize);
        bubbleView.setLayoutParams(bubbleParams);
        bubbleView.setOnTouchListener(new BubbleTouchListener());

        rootView.addView(contentContainer);

        applySideLayout();

        layoutParams = new WindowManager.LayoutParams(
                WindowManager.LayoutParams.WRAP_CONTENT,
                WindowManager.LayoutParams.WRAP_CONTENT,
                WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE | WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
                PixelFormat.TRANSLUCENT);
        layoutParams.gravity = Gravity.TOP | Gravity.START;
        layoutParams.x = getResources().getDisplayMetrics().widthPixels - dpScaled(60);
        layoutParams.y = dpScaled(176);

        windowManager.addView(rootView, layoutParams);
        rootView.post(() -> updateOverlayPosition(false));
    }

    private void removeOverlay() {
        cancelSnapAnimator();
        if (windowManager != null && rootView != null) {
            try {
                windowManager.removeView(rootView);
            } catch (Exception ignored) {
            }
        }
        contentContainer = null;
        rootView = null;
        actionPanel = null;
        bubbleView = null;
    }

    private void toggleExpanded() {
        isExpanded = !isExpanded;
        if (actionPanel != null) {
            actionPanel.setVisibility(isExpanded ? View.VISIBLE : View.GONE);
        }
        if (rootView != null) {
            rootView.post(() -> updateOverlayPosition(true));
        }
    }

    private View makeSpacer() {
        View spacer = new View(this);
        spacer.setLayoutParams(new LinearLayout.LayoutParams(dpScaled(6), 1));
        return spacer;
    }

    private TextView makeActionButton(String text, int backgroundColor, View.OnClickListener listener) {
        TextView button = new TextView(this);
        button.setText(text);
        button.setTextColor(resolveOnAccentColor());
        button.setTextSize(TypedValue.COMPLEX_UNIT_SP, 11f);
        button.setGravity(Gravity.CENTER);
        button.setTypeface(Typeface.create(Typeface.SANS_SERIF, Typeface.BOLD));
        button.setSingleLine(true);
        button.setIncludeFontPadding(false);
        button.setPadding(dpScaled(11), dpScaled(8), dpScaled(11), dpScaled(8));
        button.setBackground(makeActionBackground(backgroundColor));
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
            button.setElevation(dpScaled(1));
        }
        button.setOnClickListener(listener);
        return button;
    }

    private GradientDrawable makePanelBackground() {
        GradientDrawable drawable = new GradientDrawable();
        drawable.setColor(resolvePanelColor());
        drawable.setCornerRadius(dpScaled(16));
        drawable.setStroke(Math.max(1, dpScaled(1)), resolvePanelStrokeColor());
        return drawable;
    }

    private RippleDrawable makeActionBackground(int color) {
        GradientDrawable content = new GradientDrawable();
        content.setColor(color);
        content.setCornerRadius(dpScaled(12));
        return new RippleDrawable(
                ColorStateList.valueOf(adjustAlpha(resolveOnAccentColor(), 0.18f)),
                content,
                null);
    }

    private RippleDrawable makeBubbleBackground() {
        GradientDrawable content = new GradientDrawable(
                GradientDrawable.Orientation.TL_BR,
                new int[] {
                        lightenColor(resolveMonetColor(0xFF6650A4), 0.12f),
                        resolveMonetColor(0xFF6650A4)
                });
        content.setShape(GradientDrawable.OVAL);
        content.setStroke(Math.max(1, dpScaled(1)), adjustAlpha(resolveOnAccentColor(), 0.24f));
        return new RippleDrawable(
                ColorStateList.valueOf(adjustAlpha(resolveOnAccentColor(), 0.16f)),
                content,
                null);
    }

    private void applySideLayout() {
        if (contentContainer == null) {
            return;
        }
        contentContainer.removeAllViews();

        int gap = dpScaled(INNER_GAP_DP);

        if (actionPanel != null && actionPanel.getLayoutParams() instanceof LinearLayout.LayoutParams) {
            LinearLayout.LayoutParams panelLp = (LinearLayout.LayoutParams) actionPanel.getLayoutParams();
            panelLp.setMargins(0, 0, 0, 0);
            if (snappedToRight) {
                panelLp.rightMargin = gap;
            } else {
                panelLp.leftMargin = gap;
            }
            actionPanel.setLayoutParams(panelLp);
        }

        if (snappedToRight) {
            if (actionPanel != null) {
                contentContainer.addView(actionPanel);
            }
            if (bubbleView != null) {
                contentContainer.addView(bubbleView);
            }
        } else {
            if (bubbleView != null) {
                contentContainer.addView(bubbleView);
            }
            if (actionPanel != null) {
                contentContainer.addView(actionPanel);
            }
        }
    }

    private void updateOverlayPosition(boolean animate) {
        if (layoutParams == null || windowManager == null || rootView == null) {
            return;
        }

        applySideLayout();

        int overlayWidth = getOverlayWidth();
        int overlayHeight = getOverlayHeight();
        int screenWidth = getResources().getDisplayMetrics().widthPixels;
        int screenHeight = getResources().getDisplayMetrics().heightPixels;
        int edgeMargin = dp(EDGE_MARGIN_DP);
        int minX = edgeMargin;
        int maxX = Math.max(edgeMargin, screenWidth - overlayWidth - edgeMargin);
        int maxY = Math.max(edgeMargin, screenHeight - overlayHeight - edgeMargin);
        int targetX = snappedToRight ? maxX : minX;
        int targetY = clamp(layoutParams.y, edgeMargin, maxY);

        layoutParams.y = targetY;
        if (!animate) {
            cancelSnapAnimator();
            layoutParams.x = targetX;
            safelyUpdateLayout();
            return;
        }

        animateSnapTo(targetX, targetY);
    }

    private void animateSnapTo(int targetX, int targetY) {
        if (layoutParams == null) {
            return;
        }
        cancelSnapAnimator();
        final int startX = layoutParams.x;
        layoutParams.y = targetY;
        snapAnimator = ValueAnimator.ofInt(startX, targetX);
        snapAnimator.setDuration(180L);
        snapAnimator.setInterpolator(new DecelerateInterpolator());
        snapAnimator.addUpdateListener(animation -> {
            if (layoutParams == null) {
                return;
            }
            layoutParams.x = (Integer) animation.getAnimatedValue();
            safelyUpdateLayout();
        });
        snapAnimator.start();
    }

    private void cancelSnapAnimator() {
        if (snapAnimator != null) {
            snapAnimator.cancel();
            snapAnimator = null;
        }
    }

    private void safelyUpdateLayout() {
        if (windowManager == null || rootView == null || layoutParams == null) {
            return;
        }
        try {
            windowManager.updateViewLayout(rootView, layoutParams);
        } catch (IllegalArgumentException ignored) {
        }
    }

    private int getOverlayWidth() {
        if (rootView == null) {
            return 0;
        }
        int width = rootView.getWidth();
        if (width > 0) {
            return width;
        }
        rootView.measure(
                View.MeasureSpec.makeMeasureSpec(0, View.MeasureSpec.UNSPECIFIED),
                View.MeasureSpec.makeMeasureSpec(0, View.MeasureSpec.UNSPECIFIED));
        return rootView.getMeasuredWidth();
    }

    private int getOverlayHeight() {
        if (rootView == null) {
            return 0;
        }
        int height = rootView.getHeight();
        if (height > 0) {
            return height;
        }
        rootView.measure(
                View.MeasureSpec.makeMeasureSpec(0, View.MeasureSpec.UNSPECIFIED),
                View.MeasureSpec.makeMeasureSpec(0, View.MeasureSpec.UNSPECIFIED));
        return rootView.getMeasuredHeight();
    }

    private int resolveMonetColor(int fallback) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
            int resId;
            if (fallback == 0xFF6650A4) {
                resId = android.R.color.system_accent1_600;
            } else if (fallback == 0xFF7D5260) {
                resId = android.R.color.system_accent2_600;
            } else {
                resId = android.R.color.system_accent3_600;
            }
            return getColorCompat(resId, fallback);
        }
        return fallback;
    }

    private int resolveOnAccentColor() {
        return Build.VERSION.SDK_INT >= Build.VERSION_CODES.S
                ? getColorCompat(android.R.color.system_neutral1_0, Color.WHITE)
                : Color.WHITE;
    }

    private int resolvePanelColor() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
            return adjustAlpha(getColorCompat(android.R.color.system_neutral1_10, 0xFFF4EEFF), 0.94f);
        }
        return 0xEEF4EEFF;
    }

    private int resolvePanelStrokeColor() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
            return adjustAlpha(getColorCompat(android.R.color.system_accent1_300, 0xFFB9A9E3), 0.38f);
        }
        return 0x40B9A9E3;
    }

    private int getColorCompat(int resId, int fallback) {
        try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                return getColor(resId);
            }
            Resources resources = getResources();
            return resources.getColor(resId);
        } catch (Exception ignored) {
            return fallback;
        }
    }

    private int lightenColor(int color, float amount) {
        int r = color >> 16 & 0xFF;
        int g = color >> 8 & 0xFF;
        int b = color & 0xFF;
        r += Math.round((255 - r) * amount);
        g += Math.round((255 - g) * amount);
        b += Math.round((255 - b) * amount);
        return Color.argb(Color.alpha(color), clamp(r, 0, 255), clamp(g, 0, 255), clamp(b, 0, 255));
    }

    private int adjustAlpha(int color, float alpha) {
        return Color.argb(Math.round(255 * alpha), Color.red(color), Color.green(color), Color.blue(color));
    }

    private int clamp(int value, int min, int max) {
        return Math.max(min, Math.min(max, value));
    }

    private int dp(int value) {
        return (int) TypedValue.applyDimension(
                TypedValue.COMPLEX_UNIT_DIP,
                value,
                getResources().getDisplayMetrics());
    }

    private int dpScaled(int value) {
        return Math.max(1, Math.round(dp(value) * SCALE_FACTOR));
    }

    private final class BubbleTouchListener implements View.OnTouchListener {
        private final int touchSlop = ViewConfiguration.get(OverlayControlService.this).getScaledTouchSlop();
        private int initialX;
        private int initialY;
        private float initialTouchX;
        private float initialTouchY;
        private boolean moved;

        @Override
        public boolean onTouch(View v, MotionEvent event) {
            if (layoutParams == null || windowManager == null) {
                return false;
            }
            switch (event.getAction()) {
                case MotionEvent.ACTION_DOWN:
                    v.setPressed(true);
                    cancelSnapAnimator();
                    initialX = layoutParams.x;
                    initialY = layoutParams.y;
                    initialTouchX = event.getRawX();
                    initialTouchY = event.getRawY();
                    moved = false;
                    return true;
                case MotionEvent.ACTION_MOVE:
                    int deltaX = (int) (event.getRawX() - initialTouchX);
                    int deltaY = (int) (event.getRawY() - initialTouchY);
                    if (Math.abs(deltaX) > touchSlop || Math.abs(deltaY) > touchSlop) {
                        if (!moved) {
                            moved = true;
                            v.setPressed(false);
                        }
                    }
                    int overlayWidth = getOverlayWidth();
                    int overlayHeight = getOverlayHeight();
                    int screenWidth = getResources().getDisplayMetrics().widthPixels;
                    int screenHeight = getResources().getDisplayMetrics().heightPixels;
                    int edgeMargin = dp(EDGE_MARGIN_DP);
                    int maxX = Math.max(edgeMargin, screenWidth - overlayWidth - edgeMargin);
                    int maxY = Math.max(edgeMargin, screenHeight - overlayHeight - edgeMargin);
                    layoutParams.x = clamp(initialX + deltaX, edgeMargin, maxX);
                    layoutParams.y = clamp(initialY + deltaY, edgeMargin, maxY);
                    safelyUpdateLayout();
                    return true;
                case MotionEvent.ACTION_CANCEL:
                case MotionEvent.ACTION_UP:
                    v.setPressed(false);
                    if (!moved && event.getAction() == MotionEvent.ACTION_UP) {
                        toggleExpanded();
                        v.performClick();
                    } else if (moved) {
                        snappedToRight = event.getRawX() >= getResources().getDisplayMetrics().widthPixels / 2f;
                        if (rootView != null) {
                            rootView.post(() -> updateOverlayPosition(true));
                        } else {
                            updateOverlayPosition(true);
                        }
                    }
                    return true;
                default:
                    return false;
            }
        }
    }
}
